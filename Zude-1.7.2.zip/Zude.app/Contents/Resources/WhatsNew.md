## version 1.7.2

### GAMES
- Your phones get your games as soon as Zude opens, without the games page having to be opened first.

## version 1.7.1

### COLLECTION & MUSIC
- A song credited to several artists ("A, B", "A & B", "A and B") shows their pictures, bio and more music, in the album column and on the artist page.

### GAMES
- Remote play: a PS5 that's on no longer reads as resting or away.
- Pair and Play says so when macOS's Local Network setting keeps Zude from the console.
- The PlayStation form checks the PSN account ID before it pairs, and says what goes in each field.

## version 1.7.0

### COLLECTION & MUSIC
- The PINNED title in the artists column folds the pinned artists away, and opens them again.
- Pinned artists show as a grid of artwork, with the artist playing just under them.
- The songs header shows one sort at a time: click to go to the next, right-click to pick one.
- An album's songs start at the top of its pane.
- Volume 70 sounds like 70, not like 100.
- Collection › Videos has a Refresh button, and a show with a single episode can be moved to Movies.

### GAMES
- Remote play: Xbox Cloud Gaming and your Xbox at home in Microsoft's player, and your PS5 or PS4 at home, as cards in the library.
- Pair and Play pairs a PlayStation and starts it while its PIN is showing; the console's messages show on screen.
- Switch 2 games play on Zude Lichii in Zude's window, with their shaders prepared as they join the library.
- On the DS, 3DS and Wii U, one screen is big and the other small, and R3 swaps them.
- A PlayStation controller's touchpad moves the pointer, and two Joy-Cons can be one player's controller.
- The controllers page draws each controller, and a corner shows the game's frame rate or its stats.
- The games library scrolls smoothly, and PlayStation and Xbox show their own logos.
- Emulators stop running once you're done with them.

### STREAMING & VIDEO
- TV: Continue Watching, watched marks, Next Up, hidden categories and channels, one search, and Next and Previous to change channels.
- The video players skip 15 seconds back and forward.
- Viewing a pinned YouTube video no longer plays its sound twice.

### QUICKPLAY & DISCOVER
- Last.fm: similar artists for Mixview and Smart DJ, and scrobbling.
- Macs that share a library share one play history.
- Radio: choose, per station, whether the songs it names go into your Shazam history.
- A wishlist of songs to buy.

### ZUDE
- No keychain prompts at launch: Zude asks for a key only when a service needs it, and Settings › Sign-ins lists them.
- Keyboard controls, and a page that lists them.
- Zude no longer reaches out to hundreds of unknown addresses for friends.
- A watcher notes hangs, slow frames and errors.

### WITH ZUDE MOBILE
- YouTube on your iPhone through this Mac: your home, subscriptions, watch later, history and search, and AirPlay to a TV or a parked car.
- Big lyrics, more music on album pages, and the wishlist on the phone.

## version 1.6.1

### NOW PLAYING & LYRICS
- Corrected 3D perspective lyrics tilt so the right side stays large and the left recedes naturally.

### COLLECTION & GAMES
- Artist column alphabet index automatically trims to fit the scrollable section without overlapping Pinned or Now Playing artists.
- Collection artist and song lists now use floating scrollbars that only appear when scrolling.
- Fixed "Looking for more…" catalog status alignment in wide song tables.
- Fixed Switch 2 `nxnative` tool discovery, BIOS key lookup, and colon-safe app names.

## version 1.6.0

### NOW PLAYING & LYRICS
- Live 3D perspective autoscrolling lyrics overlay for Song view and Now Playing.
- Action buttons in Now Playing and playing song indicators adapt to your accent color.

### COLLECTION & STREAMING
- Sideways TV Shows and Movies headers and sort subtitle rails for Streaming and Video Collection.
- Pinned and Now Playing artists pinned at the top of the collection Artists column.
- Sort by last played and number of plays across videos, songs, albums, and artists.
- Smooth scroll edge fade eliminates hard cutoffs in Video and Game libraries.
- Theme-aware social message sending modals and dialogs matching dark and light themes.
- Muted gray theme-aware sort buttons with single native chevrons.

## version 1.5.0

### COLLECTION
- Three bars beside the song playing move with its beat.
- A song's heart stays put under the pointer, and fills and pops when you like it.
- The classic Collection slides in an artist's albums and songs as you choose them.
- A song's play button sits inside its row, so pointing at it keeps it there.
- Buttons on song rows darken under the pointer in light mode instead of turning white.

### ZUDE
- Zude runs on Intel Macs as well as Apple silicon, on macOS 14 or later.
- Zude rests without using the processor, and plays music with far less of it.
- A label names whatever you point at, just above it, and never runs off the window.
- Open tabs are white, and pink is kept for what you've picked and what's playing.

### VIDEO & MOVIES
- Video Mini-Player toolbar button to pop movies and TV shows into floating Picture-in-Picture.
- Online subtitle search & instant download synchronization with millisecond offset controls.
- Full MKV multi-audio track selection with persistent series language preferences.
- Multi-season TV episode indexing and artwork support.

## version 1.4.0

### THEME & GRAPHICS
- Smooth elliptical vignette gradient in Zero Dark background theme.
- Customizable accent color themes (Zune Pink, Lime, Shore, Sky, Fire, Gold) propagating throughout the interface.
- Real-time animated 40-band bottom equalizer with dynamic accent tinting.

### COLLECTION
- 3rd column songs slide animation with automatic grid reflow centering.
- Album grid multi-sorting (By Year, Date Added, A-Z, By Artist) with pinch-to-resize gesture.
- Album tile hover actions (Play, Add to Playlist, Pin) with crisp border outlines.
- Tailscale userspace node integration for seamless remote streaming without port forwarding.

## version 1.3.1

### PLAYER
- Equalizer DSP audio tap for bit-accurate sound shaping across music playback.
- Volume leveling and silence trimming background listener.
- Crossfade transition between playlist and album tracks.
