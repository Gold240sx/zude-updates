# Zude's JS Challenge Provider for yt-dlp.
#
# YouTube's web players scramble each video's stream URLs ("signature" and "n" challenges) with JavaScript from the
# player. yt-dlp solves them with its challenge solver script (yt-dlp-ejs, in yt-dlp itself) run by a JavaScript
# runtime; Zude ships none, and doesn't need one: like Downie, it runs the script in macOS's own JavaScriptCore.
# This provider hands yt-dlp's solver program to the Zude that started yt-dlp and returns what it printed.
#
# Zude passes where to ask in ZUDE_POT_URL (its /js neighbour) and a secret for this run in ZUDE_POT_SECRET.
from __future__ import annotations

import os
import urllib.error
import urllib.request

from yt_dlp.extractor.youtube.jsc._builtin.ejs import EJSBaseJCP
from yt_dlp.extractor.youtube.jsc.provider import (
    JsChallengeProvider,
    JsChallengeProviderError,
    JsChallengeRequest,
    register_preference,
    register_provider,
)


@register_provider
class ZudeJCP(EJSBaseJCP):
    PROVIDER_NAME = 'zude'
    PROVIDER_VERSION = '1.0.0'
    BUG_REPORT_LOCATION = 'https://github.com/Gold240sx/Zude/issues'
    JS_RUNTIME_NAME = 'Zude (JavaScriptCore)'

    def is_available(self) -> bool:
        return bool(os.environ.get('ZUDE_POT_URL') and os.environ.get('ZUDE_POT_SECRET'))

    def _run_js_runtime(self, stdin: str, /) -> str:
        url = os.environ['ZUDE_POT_URL'].rsplit('/', 1)[0] + '/js'
        request = urllib.request.Request(url, data=stdin.encode(), headers={
            'Content-Type': 'application/javascript; charset=utf-8',
            'Authorization': 'Bearer ' + os.environ['ZUDE_POT_SECRET'],
        })
        # Straight to Zude on this Mac: never through a proxy.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        try:
            with opener.open(request, timeout=120) as response:
                return response.read().decode()
        except urllib.error.HTTPError as error:
            raise JsChallengeProviderError(f'Zude could not run the solver: {error.read().decode(errors="replace")}') from error
        except (urllib.error.URLError, OSError) as error:
            raise JsChallengeProviderError(f'Zude could not run the solver: {error}') from error


@register_preference(ZudeJCP)
def zude_preference(provider: JsChallengeProvider, requests: list[JsChallengeRequest]) -> int:
    return 900
