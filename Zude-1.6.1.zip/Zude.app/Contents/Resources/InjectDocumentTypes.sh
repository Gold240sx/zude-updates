#!/bin/sh
PLIST="${BUILT_PRODUCTS_DIR}/${INFOPLIST_PATH}"
[ -f "$PLIST" ] || PLIST="${INFOPLIST_PATH}"
[ -f "$PLIST" ] || PLIST="${BUILT_PRODUCTS_DIR}/${INFOPLIST_PATH}"
export PLIST
echo "InjectDebug: PLIST=$PLIST exists=$([ -f "$PLIST" ] && echo yes || echo no) BUILT_PRODUCTS_DIR=$BUILT_PRODUCTS_DIR INFOPLIST_PATH=$INFOPLIST_PATH" >> /tmp/inject_debug.log 2>&1
python3 - <<'PY' >> /tmp/inject_debug.log 2>&1
import plistlib, os, sys
p = os.environ.get("PLIST", "")
print(f"InjectDebug: python sees PLIST={p}", file=sys.stderr)
if not p or not os.path.exists(p):
    print("InjectDocumentTypes: Info.plist not found", file=sys.stderr)
    sys.exit(0)
d = plistlib.load(open(p, "rb"))
before = d.get("CFBundleDocumentTypes")
# What Finder offers to open with Zude: it plays them where they are (they aren't added to the collection).
d["CFBundleDocumentTypes"] = [
    {
        "CFBundleTypeName": "Audio File",
        "CFBundleTypeRole": "Viewer",
        "LSHandlerRank": "Default",
        "LSItemContentTypes": [
            "public.mp3",
            "public.mpeg-4-audio",
            "com.apple.m4a-audio",
            "com.apple.protected-mpeg-4-audio-b",
            "org.xiph.flac",
            "com.microsoft.waveform-audio",
            "public.aiff-audio",
            "public.aifc-audio",
            "public.aac-audio",
            "com.apple.coreaudio-format",
        ],
    },
    {
        "CFBundleTypeName": "Video File",
        "CFBundleTypeRole": "Viewer",
        "LSHandlerRank": "Default",
        "LSItemContentTypes": [
            "public.mpeg-4",
            "com.apple.m4v-video",
            "com.apple.quicktime-movie",
            "public.mpeg",
            "public.mpeg-2-transport-stream",
            "public.3gpp",
            "public.3gpp2",
        ],
    },
]
# Friend invites are zude://invite/… links (the social page); Xcode's generated Info.plist has no setting for URL types.
d["CFBundleURLTypes"] = [{"CFBundleURLName": "com.inovadev.zude.invite", "CFBundleURLSchemes": ["zude"]}]
# Phones nearby find this Mac while it's pairing (Remote Access › Pair a device): MultipeerConnectivity, over Bluetooth
# or Wi-Fi between the two. Its service, with Remote Access's own, for local network privacy.
d["NSBonjourServices"] = ["_zude._tcp", "_zude-pair._tcp", "_zude-pair._udp"]
d["NSBluetoothAlwaysUsageDescription"] = "Zude lets your iPhone find this Mac over Bluetooth while you pair it, so it can pair without being on the same network."
# Xcode's generated Info.plist has no build setting for this key: the Now Playing fire's Apple Music and Spotify tap needs it.
d["NSAudioCaptureUsageDescription"] = "Zude listens to Apple Music and Spotify as they play so the Now Playing fire can move with the music. Nothing is recorded."
# App updates (Sparkle, see SoftwareUpdates.swift and Scripts/release.sh). The feed must be somewhere public (the source
# repository is private). The public key is `generate_keys -p`'s: its private half is in the login keychain of the Mac
# that makes releases (Sparkle's "ed25519" item), and Sparkle installs only updates signed with it.
SPARKLE_FEED_URL = "https://gold240sx.github.io/zude-updates/appcast.xml"
SPARKLE_PUBLIC_KEY = "A//kfQ3Sx/6+HYC/GqkONTocoY/wmPdedrKu3IakKj0="
d["SUFeedURL"] = SPARKLE_FEED_URL
if SPARKLE_PUBLIC_KEY:
    d["SUPublicEDKey"] = SPARKLE_PUBLIC_KEY
d["SUEnableInstallerLauncherService"] = True
d["SUEnableAutomaticChecks"] = True
d["SUScheduledCheckInterval"] = 86400
plistlib.dump(d, open(p, "wb"))
print(f"InjectDocumentTypes: injected CFBundleDocumentTypes into {p}", file=sys.stderr)

# Bundle release history from plans.md into WhatsNew.md for the in-app What's New card.
srcroot = os.environ.get("SRCROOT", "")
res_dir = os.path.join(os.environ.get("BUILT_PRODUCTS_DIR", ""), os.environ.get("UNLOCALIZED_RESOURCES_FOLDER_PATH", ""))
plans_path = os.path.join(srcroot, "plans.md") if srcroot else ""
if plans_path and os.path.exists(plans_path) and res_dir and os.path.isdir(res_dir):
    import re
    with open(plans_path, "r", encoding="utf-8") as f:
        lines = f.read().splitlines()
    out = []
    in_version = False
    for line in lines:
        if line.startswith("## "):
            if re.match(r"^##\s+(?:Now:\s+)?version\s+\d", line, re.IGNORECASE):
                in_version = True
                out.append(line)
            elif line.startswith("## Earlier releases"):
                continue
            elif in_version:
                if "version" not in line.lower():
                    in_version = False
                else:
                    out.append(line)
        elif in_version:
            out.append(line)
    if out:
        with open(os.path.join(res_dir, "WhatsNew.md"), "w", encoding="utf-8") as out_f:
            out_f.write("\n".join(out) + "\n")
PY
