## Now: version 1.6.0 — 3D Perspective live lyrics, vertical streaming & collection video rails, pinned & now-playing artist headers, theme-aware modals & sort buttons, scroll edge fades, video miniplayer pop-out, and play count & last played sorts (asked 2026-11-11) — done; built and tested

### Features
- **3D Perspective Live Autoscrolling Lyrics Overlay for Song Page & Now Playing (`PerspectiveLyricsView`, `ZuneArtistView`)**:
  - Replaced the static dark boxed lyrics card in the song detail view (`SongPageView`) with a dynamic semi-opacity lyrics overlay featuring real-time playback synchronization and an inward 3D perspective (`rotation3DEffect(18°)` with right edge large/prominent and left edge receding inward), directly bringing mobile Zude's signature lyrics experience to desktop.
  - Sized lyrics prominently with right alignment, smooth top and bottom linear gradient edge fading, bright white active line highlight, and translucent resting lines (`opacity: 0.55`).
  - Implemented responsive live autoscrolling (`ScrollViewReader.scrollTo`) centered around the currently sung line (`UnitPoint(x: 1, y: 0.35)`), with user interaction detection (pause autoscrolling for 3 seconds on manual drag) and tap-to-seek functionality.
  - Added responsiveness to player wideness (`pageWidth >= 780`): when wide enough, lyrics float seamlessly on the right over the song hero banner; on narrow windows, hero layout stays compact and uncrowded.
  - Relocated Now Playing lyrics in `ZuneArtistView` when space is available (`geo.size.width >= 750`): moved lyrics from the lower-left corner beneath the track headlines over to the right side with matching 18° inward perspective, clear of the vertical plays counter, and applied matching perspective rotation to `LyricsWall`.
- **Vertical Title & Sort Subtitle Rail with Right-Side Shelves for Streaming & Collection Video (`PlexLibraryView`, `VideoViews`)**:
  - Replaced the filter icon button on the streaming page (`PlexLibraryView`) with a vertical sideways sort subtitle (`BY DATE ADDED ˅`, `BY NAME ˅`, etc.) matching the signature `TV Shows` and `Movies` sideways text (rotated -90°).
  - Clicking the vertical sort subtitle triggers an AppKit `NSMenu` displaying all available sort orders (`Name`, `Date Added`, `Release Date`, `Year`) with checkmarks on the active sort, alongside dynamically populated submenus for `Genres` and `Studios/Networks` when available on the active shelf, and a `Clear Filter` item when narrowing is active.
  - Moved the shelf navigation list (`ALL`, `CONTINUE WATCHING`, `ON DECK`, `RECENTLY ADDED MOVIES`, `RECENTLY ADDED TV SHOWS`, `NOW STREAMING`, `FOR YOU`, `NEW MOVIES`, `NEW TV`, `POPULAR`) from the left rail over to a dedicated right rail column (`width: 185`, trailing aligned), eliminating hover sliding and letting posters expand across the central canvas.
  - Replicated this unified vertical architecture on the Collection Video page (`VideoViews.swift`):
    - Left rail: Sideways `TV Shows` and `Movies` links (34pt SegoeZ-Light, switching `shell.videoView`) plus sideways sort subtitle (`BY SERIES ˅`, `BY DATE ADDED ˅`, `BY LAST PLAYED ˅`, `BY # OF PLAYS ˅`, `BY GENRE ˅`) with click-to-sort popup menu.
    - Right rail: Video count header (`73 VIDEOS`), vertical category list (`ALL`, `TV SHOWS`, `MOVIES`, `MUSIC VIDEOS`, `OTHER`), and layout switcher (`LAYOUT: GRID, LIST VIEW, FOLDERS`).
    - Center: Expansive video grid, list, or folder view without top horizontal pivot clutter.
  - Created shared `Sideways` layout and `ContextMenuHelper` in `ZuneTheme.swift` with theme-aware muted gray coloring (`isDark ? Color.white.opacity(0.65) : Color.black.opacity(0.55)`).
- **Pinned & Now Playing Artist Header Section & Muted Gray Sort Buttons (`MusicLibraryView`, `LibraryPanels`)**:
  - Pinned `All artists`, the currently playing artist (with dynamic accent play glyph), and any Quickplay-pinned artists (under a dedicated `PINNED` subtitle) at the top of the collection artist column above the scrollview.
  - Kept all artists (including pinned and now-playing artists) in the scrollview below without filtering them out, preserving complete alphabet index navigation (`#`, `A`–`Z`) and total artist counts.
  - Pinned and Now Playing rows provide full interactive parity: single click selects artist, double click plays their tracks, right click opens context menus, and drag gestures initiate playlist additions.
  - Styled all sort header dropdown buttons (`artistSortMenu` in `MusicLibraryView`, `albumHeaderView` in `LibraryPanels`, and `headerSort` in `LibraryPanel`) with explicit `.foregroundStyle(mutedSortColor)`, rendering them in muted gray (lighter in dark themes: `white.opacity(0.65)`, darker in light themes: `black.opacity(0.55)`).
- **Video Mini-Player Toolbar Pop-out for TV, Music Videos, & Movies (`BottomToolbar`, `PlayerEngine`)**:
  - Added a dedicated Picture-in-Picture mini-player button (`pip.enter`) directly to the right of the Equalizer button in `BottomToolbar` whenever watching movies, TV shows, Live TV channels, or music videos.
  - Widened the `TransportControls` right button container (`sideWidth: 104`) so the Queue, Equalizer, and Mini-Player buttons fit without crowding or clipping.
  - Enhanced `PlayerEngine.playingVideo` to recognize all video categories (including `.tv`, `.music`, `.movies`) and `.tv` streaming sources, providing seamless mini-player pop-out and full transport controls for music videos and live broadcasts.
  - Clicking pops the video out of Now Playing into Zude's floating `VideoMiniPlayer` window (above other windows), and clicking it again returns seamlessly to full-window Now Playing.
- **TV Channel Catalog Cleanup (`FreeChannels`)**:
  - Removed Arabic channels (`Al Jazeera Arabic`, `DW Arabic`, `France 24 Arabic`) from the built-in free live TV broadcaster streams in `FreeChannels.swift`.
  - Updated provider setup descriptions in `TVAddProviderDialog.swift` and updated `FreeChannelsTests` in `TVSourcesTests.swift`.
- **"By Last Played" & "# of Plays" Sort Options Across Videos, Songs, Albums, & Artists**:
  - Added `.lastPlayed` ("by last played") and `.plays` ("# of plays") to `VideoSort` across all video views (All, TV Shows, Music Videos, Movies, and Other), sorting by most recently watched and highest play count descending.
  - Registered `"IDS_DATE_LAST_PLAYED_SORT"` (`"by last played"`) and `"IDS_PLAYS_SORT"` (`"# of plays"`) in `ZuneStrings.json`.
  - Added full `"by last played"` and `"# of plays"` sorting across:
    - **Songs**: Rendered as authentic Zune secondary pivots (`ZunePivotList`) across the header of the full-width Songs collection view (`a-z`, `by last played`, `# of plays`, `by date added`, `by artist`, `by album`), with instant descending sorts by play count and recent play history, synchronized with `SongSort` and `SongColumn`.
    - **Albums**: Integrated `"by last played"` and `"# of plays"` into `AlbumSortOption` across `AlbumList` and `AlbumGrid` in Collection › Music › Albums and artist/genre album columns, computing maximum play counts and recent play timestamps per album.
    - **Artists**: Integrated `"by last played"` and `"# of plays"` into `ArtistSortOption` across list and grid views in Collection › Music › Artists, aggregating artist-wide play counts and play dates.
    - **Artist Discography**: Added `"by last played"` and `"# of plays"` tertiary pivots to `ArtistPageView.AlbumSort` for discography releases.
  - Updated `VideoSortTests` in `VideoInfoTests.swift` asserting options and group order.
- **Artist Page Dynamic Loading Feedback & Streaming Catalog Indicators (`ArtistPageView`, `MoreMusicStore`)**:
  - Implemented responsive, real-time loading feedback across artist pages when browsing in Discover or opening artists with 0 local songs:
    - Added `MoreMusicStore.isChecking(artist:)` and `MoreMusicStore.isChecking(album:artist:)` to distinguish between active background streaming catalog queries and truly empty artist catalogs.
    - Suppressed premature "No songs by <artist> in your collection or Spotify library yet" dead-end messages while online catalog lookups from Spotify, Apple Music, and YouTube Music are actively running.
    - Added an inline progress indicator (`Loading additional info…`) alongside the song and album count header while catalog queries are in progress.
    - Fixed trailing dot (`" · "`) artifact in artist header summaries when total duration is zero or absent.
    - Added placeholder loading states for the "POPULAR" track list and "DISCOGRAPHY" album grid, keeping the page layout structured and informing the user that releases and popular songs are being fetched from streaming catalogs.
- **Dynamic Accent Color Synchronization Across Now Playing, Songs Panel, & Edit Info Overlay (`AccentTheme`)**:
  - Bound remaining hardcoded magenta UI elements to the active accent theme (`settings.accentTheme`):
    - **Now Playing Action Buttons**: Added `AccentTheme.hueRotationAngle` dynamically shifting round Zune state buttons (`INFO.NP`, `RATING.NP.NOWPLAYING`), tinted `MixIconButton` (`MIX.MIX`), and updated `NowPlayingStarButton` circle border and glyph to the active accent palette (Lime, Shore, Sky, Fire, Gold, or classic Zune). Updated track link hover states and the Now Playing queue's playing track label.
    - **Songs Table & Column Views (`SongsPanel.swift`)**: Updated the now-playing row play indicator (`▶`), suggested track sparkles, playing title label, and liked hearts to use the user's selected accent color. Applied accent colors to drag walls, column drop targets, multi-select checkboxes (`SelectBox`), and download progress rings.
    - **Edit Info Panel Overlay (`MetadataEditorPanel.swift`)**: Replaced hardcoded pink left-edge border line with the dynamic accent color. Updated `ZuneFilledButton` primary action buttons (`SAVE`, `RENAME`, `APPLY`, `FIND`, `RUN`) to render with the active accent color, and updated cover art drop target borders.
    - **Edit Album Info Dialog (`EditInfoDialog.swift`)**: Synchronized the signature dialog energy bar gradient with the user's chosen palette.
- **Theme-Aware Social Message Modals & Sheets (`SocialComposer`, `ShareOutSheet`)**:
  - Made the "SEND MESSAGE" (and "SEND SONG", "SEND ALBUM", etc.) composer modal dynamically adapt to all active themes (Zero Dark, Aurora, Frosted Glass, and Zero light):
    - Removed hardcoded solid white background and forced light colorScheme (`.environment(\.colorScheme, .light)`).
    - Added dynamic background rendering using `DarkThemeGradient()` in Zero Dark, popover visual effect material in Frosted Glass, and rich Aurora wallpaper overlays.
    - Added themed containers for the collection attachment search bar and message `TextEditor` with hidden scroll content background, high-contrast readable text, and adaptive border styling.
    - Updated friend recipient pills to render subtle glass capsules in dark mode that dynamically illuminate with Zune magenta when selected.
    - Updated `ShareOutSheet` with matching theme background, glass buttons, and adaptive typography.
- **Scroll Edge Fade Across Video Views & Games Library (`scrollEdgeFade`)**:
  - Eliminated hard, jarring cutoffs at the top and bottom of scrollable views by adopting dynamic edge fading:
    - **Collection › Videos (`VideoViews.swift`)**: Added `.scrollEdgeFade()` across `VideoGrid`, `VideoList`, and `VideoFolderView`, ensuring thumbnails and posters fade out smoothly before colliding with the top sort/layout header or the bottom transport footer. Added bottom scroll padding (`.padding(.bottom, 20)`) for comfortable end-of-scroll spacing.
    - **Games Library (`GamesView.swift`, subpages)**: Integrated `.scrollEdgeFade()` into `GameCoverGrid` and `GameRecentRows`, and extended coverage across all Games subviews (`GameWishlistPage`, `GameSystemsPage`, `GameCoresPage`, `GameControllersPage`, `GameFriendsPage`, and `GamePage`).
    - **Plex & Detail Overlays**: Enhanced `PlexDetailView`, `PlexPersonView`, and `LibraryPanels` albums panel with `.scrollEdgeFade()`.

### Bugfixes
- **Sparkle Release Distribution Asset Optimization & Bundle Footprint**:
  - Unlinked redundant duplicate Tailscale static library from background login helper `Zude Helper`, leaving CloudKit remote-wake handling intact while saving over 20MB uncompressed / 8.2MB compressed.
  - Symlinked duplicate `_internal/Python` shared library to `Python.framework` in embedded `yt-dlp`, saving 14.7MB uncompressed / 5.3MB compressed.
  - Resampled large placeholder and device graphics (`NOART.*.PNG`, `DEVICE.*.LARGE.PNG`) to high-density Retina dimensions (384pt), saving 12.5MB and bringing the final release zip comfortably under GitHub's 100MB asset distribution threshold for instant Sparkle deployment.
- **TailscaleKit Universal x86_64 Architecture Build Compatibility (`TailscaleService.swift`)**:
  - Gated `TailscaleKit` imports and direct API references behind `#if canImport(TailscaleKit)` with graceful fallback stubs on Intel Macs (`x86_64`), preventing compiler failures during universal release archiving while preserving complete tsnet functionality on Apple Silicon.
- **Collection Album & Artist Sort Header Dropdown Single Chevron & Theme-Aware Gray Tint (`LibraryPanels`, `MusicLibraryView`)**:
  - Fixed duplicate chevron arrows in the album and artist collection column sort headers (`1 ALBUM ˅ BY YEAR ˅` / `3406 ARTISTS ˅ A-Z ˅`).
  - Identified AppKit's SwiftUI popup button bridging behavior where placing an `Image(systemName: "chevron.down")` in the `Menu`'s label caused `NSButton` to render the image on the left as a button icon while `NSPopUpIndicatorView` simultaneously rendered the native down indicator on the right.
  - Removed manual `Image` chevron from `Menu` labels in `LibraryPanels.albumHeaderView` and `MusicLibraryView.artistSortMenu`, allowing AppKit to render a single, native down arrow on the right of the sort title (`BY YEAR ˅`, `A-Z ˅`).
  - Styled sort dropdown menus in muted gray (`isDark ? Color.white.opacity(0.65) : Color.black.opacity(0.55)`), overriding the root window accent color tint and ensuring high contrast and legibility across both dark and light themes.
  - Made the column count headers (`1 ALBUM`, `3406 ARTISTS`) theme-aware (`isDark ? Color.white : ZuneColor.black`), preventing white text washout on light backgrounds.


## version 1.5.0 — Subtitle search & download sync, audio track selection, multi-season TV episode indexing, gecko placeholder album art, and non-blocking Tailscale bridging (asked 2026-11-11) — done; built and tested

### Features
- **Online Subtitle Downloader & Real-Time Sync Engine (`SubtitleManager`)**:
  - Implemented `SubtitleManager` integrating the OpenSubtitles REST provider for instantaneous online subtitle queries by movie/series title, season, and episode across multiple languages (English, Spanish, French, German, Italian, Portuguese, Dutch, Russian, Chinese, Japanese, etc.) without requiring API keys.
  - Automatic download and transparent on-the-fly Gzip decompression (`decompressGzip`) with instant `.srt` cue parsing (`SubtitleCue`).
  - Added dedicated `SubtitleSearchSheet` accessible directly from the player's Closed Captions menu with language picker, SDH (hearing impaired) indicators, live search progress, and 1-click download activation.
  - Automatic sidecar `.srt` persistence alongside the playing video file and caching in `Application Support/Zude/Subtitles/`.
  - Added millisecond-accurate subtitle sync offset controls (`-0.5s`, `+0.5s`, `Reset`) directly in the footer subtitles menu and search sheet to synchronize dialogue with video streams.
  - Created `VideoSubtitleOverlay` rendering cinematic, high-legibility subtitle cues with rounded translucent backdrops and drop shadows over video playback in `NowPlayingView`.
  - Automatic local sidecar subtitle detection (`checkForSidecar`) whenever local video files are played.
- **Dark & Light Gecko Placeholder Album Art (`ZudePlaceholderCover`)**:
  - Designed resolution-independent vector-sharp placeholder artwork featuring the official Zude gecko insignia instead of the legacy Zune logo across both dark and light modes.
  - Generated and registered dark variants across all 12 crisp asset dimensions (`NOART.DARK.PNG`, `NOART.DARK.BIG.PNG`, `NOART.DARK.NOWPLAYING.BIG.PNG`, etc.) in `ZudeCrispImages.json`.
  - Updated `ZuneAssets.swift` and `BottomToolbar.swift` to dynamically resolve dark cover assets whenever running on the Zero Dark theme or Frosted Glass in dark mode.
- **Custom Dark Modal Software Update Flow & What's New Overview (`SoftwareUpdates`, `SoftwareUpdateViews`)**:
  - Replaced Sparkle's generic standard alert windows by implementing `SPUUserDriver` directly on `SoftwareUpdates`, hosting the full update sequence inside a sleek dark modal overlay (`SoftwareUpdateOverlay`) centered over Zude's main window.
  - Built dedicated cards directly replicating the reference update flow across all 6 stages:
    1. **Looking / Checking (`UpdateCheckingCard`)**: Uppercase bold `UPDATES` eyebrow, lowercase `looking...` title in light Segoe font, `YOU HAVE <VERSION>`, animated horizontal indeterminate progress bar oscillating smoothly across the full width, and an outline capsule `CANCEL` button.
    2. **Update Available (`UpdateAvailableCard`)**: Bold `A NEW VERSION` eyebrow, white `zude` with signature gradient version number (`zude 1.2`), subtitle with download size (`YOU HAVE 1.1 · 16 MB DOWNLOAD`), scrollable categorized release notes with section icons (`≡ COLLECTION`) and gradient rectangular dash bullets, plus `SKIP THIS VERSION`, `LATER`, and solid white `INSTALL` capsule buttons.
    3. **Downloading (`UpdateDownloadingCard`)**: Bold `DOWNLOADING` (or `PREPARING` during extraction), `zude <version>`, live downloaded byte progress (`4 MB OF 16 MB`), oversized ultra-light percentage readout (`27%`) on the right, smooth determinate gradient progress bar, and `CANCEL` button.
    4. **Ready to Install (`UpdateReadyCard`)**: Bold `READY TO INSTALL`, `zude <version>`, descriptive subtitle ("Zude closes and opens again on the new version, and the music stops."), with `LATER` and solid white `INSTALL AND RELAUNCH` action buttons.
    5. **What's New Overview (`UpdateWhatsNewCard`)**: Faint lowercase `"new"` watermark, bold `WHAT'S NEW`, `zude <version>`, rich scrollable multi-version release history with section headers, gradient dashes, version divider lines, and solid white `CONTINUE` button.
    6. **Status & Error Cards (`UpdateStatusCard`)**: Polished feedback for up-to-date confirmations and transient updater errors.
  - Pixel-perfect visual polish matching the Zune / Zunic software design language:
    - Matte slate card surface (`#19191A`) with sharp 90-degree corners, subtle 1px border stroke (`Color.white.opacity(0.12)`), and deep 38pt drop shadow.
    - Flush left-edge vertical accent bar (4.5px wide × 38px tall) with top-to-bottom cyan-to-purple BrandTag gradient.
    - Signature cyan-to-purple linear gradient (`#29ADF2` to `#6B66EB`) dynamically applied across version heroes, progress bars, left-edge accent tags, and bullet dashes on default Zune theme, automatically adapting to user-chosen accent palettes.
    - Authentic Zune Segoe Z typography (`SegoeZ-Light`, `SegoeZUC-Bold`, `SegoeZ-SemiBold`, `SegoeZ`) with graceful system font fallbacks.
    - Oversized faint top-right background watermarks (`1.1`, `1.2`, `new`) in light 136pt font.
  - Bundled `WhatsNew.md` into app resources (`Zude/ZuneResources/WhatsNew.md`) with multi-version changelog history, and added an in-app `PREVIEW UPDATE SCREEN` button in Settings › About (under `#if DEBUG`) allowing instant visual testing and cycling through all 5 screens in sequence.

### Bugfixes
- **Thread Exhaustion Crash Fix (`Thread 1554: EXC_BAD_ACCESS (code=2)`)**:
  - Resolved fatal kernel protection failure caused by unbounded GCD thread creation and synchronous `DispatchGroup.wait()` blocking inside `TailscaleService.bridgeConnection`.
  - Converted the Tailscale raw TCP bridge into an asynchronous, non-blocking pipeline using dedicated `bridgeQueue`, graceful half-close socket shutdowns (`Darwin.shutdown(..., SHUT_WR)`), and asynchronous `notify` cleanup.
  - Added error backoff (100ms) to `tailscale_accept` to prevent tight busy-spinning loops on socket disconnects or transient errors.
- **TV Shows & Animaniacs Episode Hierarchy Import Bug**:
  - Fixed regression in `PlexMediaIndexer.parseSeasonFolder` where folders named `<Show> Season <N>` (e.g. `Animaniacs Season 1 (1993-1994)`) failed to match the season regex, returning `isSeason = false` and causing all episodes across all seasons to default to `season: 1, episode: 1`.
  - Expanded `parseEpisodeHierarchy` to support:
    - Leading episode numbers (`01 - Title`, `02 - Title`) regardless of whether the folder is explicitly flagged as a season directory.
    - 3-digit and 4-digit notation (e.g. `101`, `204`, `0101`).
    - Show prefix extraction from compound season directory names.
  - Changed default unparsed episode index to 0 so unnumbered special features and extras are not deduplicated or dropped by `bestCopies`.
- **Audio Track & Closed Captions Menu Responsiveness**:
  - Fixed regression in `BottomToolbar.swift` where `PlexClosedCaptionsMenu` and `PlexAudioTrackMenu` were disabled (`enabled: false`) when watching non-Plex videos or when stream metadata had not yet loaded asynchronously.
  - Both menus remain interactive and responsive whenever `player.playingVideo` is active, allowing users to switch audio tracks, toggle subtitles, and search/download subtitles online at any time.
- **MKV Multi-Audio Track Selection, Series Audio Preference & Default Language Selection**:
  - Fixed bug in `FilmRemux.init`, `TVEngine.film`, and `PlexClient.playback` where `.mkv` files always played the container's `isDefault` audio track (e.g. French track 1 in `MULTi` releases like *Malcolm in the Middle*) and ignored both user audio selections in `PlexAudioTrackMenu` and Settings' default Audio Language preference.
  - Replaced `PlexMediaIndexer.extractMediaTracks`'s placeholder single-audio metadata for `.mkv` files with real Matroska header parsing (`extractMKVTracks`), exposing every real audio and subtitle track with codec, channels, language tag, and container track number (`PlexStream.index`), and automatically refreshing previously cached legacy `.mkv` entries.
  - Added per-series audio language persistence (`PlexLanguages.seriesAudioLanguage` / `setSeriesAudioLanguage`) so choosing an audio track while watching any episode immediately switches the playing track at the current timestamp and persists across the entire series, while diverting to Settings' preferred Audio Language (`PlexLanguages.preferredAudioLanguage` / `.alwaysPreferred`) when available across Flex, Plex, and Collection video playback.
  - Exposed Audio Language and Subtitles & Closed Captions preferences in `SettingsView` › Streaming unconditionally for both Flex/local libraries and remote Plex accounts.
- **Video Playback, Episode List Scrolling & App Performance Beachball Fixes**:
  - Resolved massive CPU flooding and UI freezing (`<<< timebase >>> signalled err=-12753` repeated thousands of times per second, `AudioConverter` format status `1718449215` / `'fmt?'` failure) caused by `EqualizerDSP.attach(to: item)` unconditionally attaching an `MTAudioProcessingTap` audio mix to video player items and HLS streams. Limited `EqualizerDSP.attach` strictly to audio music items in both `PlayerEngine.swift` and `Equalizer.swift`.
  - Resolved severe disk-thrashing and GPU process stalls (`GPU process took 1.24s to launch`, `<<< FFR_AVI >>> err=-12848`, `<<< FFR_Common >>> err=-12847`) when scrolling episode lists in `PlexDetailView`. In `PlexServerEngine`, stopped falling back to raw video file paths (e.g. `.mkv`) for artwork transcoding, falling back instead to season/show artwork. In `PlexStreamServer.transcodeImage`, restricted `AVAssetImageGenerator` strictly to native Apple video containers (`mp4`, `m4v`, `mov`, `qt`, `3gp`), instantly generating sleek fallback cards for non-Apple video files without stalling the disk or GPU.
  - Eliminated `Could not open() the item: [21: Is a directory]` by adding directory checks prior to image transcoding in `PlexStreamServer`, track loudness analysis in `TrackAnalyzer`, and audio metering in `LoudnessAnalyzer`.
  - Added explicit handle closure (`reader.close()`) in `PlexMediaIndexer.extractMKVTracks` and refined MKV placeholder detection in `extractMediaTracks` to prevent redundant full-file Matroska parses on previously indexed `.mkv` files.


## version 1.4.0 — User-updatable emulator cores, Lichii Nintendo Switch 2 support, background threading, gameplay footer peek, and NX Native compilation (asked 2026-11-10) — done; built and tested

### Features
- **Dark Theme Vignette Gradient**:
  - Implemented a smooth elliptical vignette gradient (`DarkThemeGradient`) for the Zero Dark background theme using `#211F21` at the center and `#110B0F` at the outer perimeter, matching the requested reference styling.
  - Automatically rendered in `FrameBackground` when dark mode is enabled without a custom image, and previewed in Settings › Screen › Graphics swatch.
- **Customizable Accent Colors & Dynamic UI Propagation**:
  - Created `AccentTheme` in `AccentTheme.swift` with 6 distinct color themes:
    - **Zune (Default)**: Classic Magenta (`#F10DA2`) to Orange (`#E9580A`).
    - **Lime**: `#2AE600` to `#BEE600`.
    - **Shore**: `#34CCE6` to `#42E6BE`.
    - **Sky**: `#15C0E6` to `#217EE6`.
    - **Fire**: `#E6C51C` to `#E63B25`.
    - **Gold**: `#F6D667` to `#BF8F30` to `#5E3901`.
  - Added user-selectable accent theme picker in `SettingsView` under Screen › Graphics with live preview swatches.
  - Seamlessly wired accent color propagation across all 8 requested UI areas:
    1. **AI Trigger Box (`BrandTag`)**: Custom vertical linear gradient on active accent themes, preserving the original vertical asset on default Zune pink.
    2. **Zude Logo Backing Tile**: Custom linear gradient filling the logo tile backing while preserving the classic magenta-to-orange gradient on default Zune pink.
    3. **Progress Bars**: Set `.tint(...)` on the root view hierarchy and customized `LoadStatusBar` and Now Playing sliders to follow the accent theme.
    4. **Selected Artist Text & Badges**: Selected rows (`ArtistListRow`, `AllArtistsRow`), selected artist grid tiles (`ArtistGridTile`), and pinned badges dynamically highlight with the chosen accent color.
    5. **Footer Playback Controls**: Transport icons and glass buttons (`GlassIconButton`, `PlainIconButton`, `PlainIconMenu`, `FavoriteHeart`, `VolumeControls` slider & mute speaker) adapt to the active accent theme.
    6. **Now Playing Bar**: Seek slider gradient track and output target text dynamically follow the accent theme.
    7. **Background Process Progress Bar**: Candy stripe loading bar and shimmer effect reflect the active accent color.
    8. **Animated Bottom Equalizer (`ZuneFireView`)**: Real-time 40-band bottom player EQ dynamically tints its two animated sprite layers using cached tinted images (`eqColors`), animating only when music is playing and retaining 100% original sprites on default Zune pink.
- **Collection & Library View Enhancements (Collection › Music)**:
  - **Dynamic 3rd-Column Songs Animation & Grid Reflow Centering**:
    - Updated `MusicLibraryView.threeColumns` to hide the 3rd column (songs list) on the Artists tab until an album is selected, letting the albums column take full width.
    - When an album is selected, the 3rd column animates in with a trailing slide transition (`.transition(.move(edge: .trailing).combined(with: .opacity))`), while the divider fades in.
    - Wrapped the middle column in `ScrollViewReader` with timed reflow tracking (`scrollToSelectedAlbum` at 0ms, 120ms, and 300ms) to ensure the selected album remains centered in view as the albums grid narrows and wraps into fewer columns.
  - **Album Grid Multi-Sorting, Pinch-to-Resize & Artist Grouping (`BY ARTIST`)**:
    - Added multi-sorting options in `AlbumList`: `BY YEAR`, `BY DATE ADDED`, `A-Z`, and `BY ARTIST`.
    - When sorted `BY ARTIST`, albums are grouped under thin lowercase artist section headers (e.g. `"weird al" yankovic`, `100 gecs`) in `Zune.font(.light, 28)`.
    - Added pinch-to-resize trackpad gesture (`MagnificationGesture`) scaling album tiles smoothly between 70pt and 240pt, persisted in `@AppStorage("AlbumGrid.TileSize")`.
  - **Album Tile Hover Action Buttons**:
    - Circular Play, Add to Playlist (`+`), and Pin buttons overlay the top right of album art when hovered, with a dark translucent circular background and crisp 1.5pt white border outline.
    - Added a 2pt white border outline around the album art when hovered or selected.
  - **Songs & Artists Header Sort Dropdowns**:
    - Added sort menu dropdown next to `# SONGS` (`A-Z`, `BY ARTIST`, `BY ALBUM`, `BY DATE ADDED`, `BY YEAR`, `BY PLAY COUNT`) updating `"SongColumns.Sort"`.
    - Added sort menu dropdown next to `# ARTISTS` in `LibraryPanel` (`A-Z`, `Z-A`, `BY ALBUMS`, `BY SONGS`) with white count and warm gray sort option.
  - **Artists Grid View & Album/Song Counts**:
    - When "All artists" is selected in the Artists list, the middle column displays the full grid of artists with `headerSort: AnyView(artistSortMenu)`.
    - Under each artist tile, displayed artist name and `# albums · # songs` subtitle (e.g. `2 albums · 2 songs` / `1 album · 1 song`) in warm gray font.
  - **Album Header Typography & Layout**:
    - Updated album title font to thin weight (`Zune.font(.light, 30)`) with reduced top padding.
    - Inserted circular artist avatar and artist name row between the album title and duration/song count.
    - Removed redundant artist name under each track title in the album songs list.
  - **Font Size Settings**:
    - Added a `Standard` (1.075 scale) middle-ground option between `Small` (1.0) and `Medium` (1.15) in `AppSettings.FontSizeOption`.
- **Embedded Tailscale & 1-Click Interactive Sign-In for Cellular Remote Streaming**:
  - Embedded `TailscaleKit.xcframework` (compiled from `libtailscale` with userspace `tsnet` Go stack) as a universal static XCFramework supporting macOS (Apple Silicon), iOS (arm64), and iOS Simulator (arm64 & x86_64).
  - Integrated `TailscaleService` managing userspace node lifecycle, persistent key storage across launches (`Application Support/Zude/tailscale` or shared App Group `group.com.inovadev.zude/tailscale` on macOS and `<Documents>/tailscale` on iOS), and interactive web authentication without requiring pre-shared auth keys or third-party server hosting.
  - Interactive browser login flow (`signIn()`): initiates userspace authentication, extracts dynamic `AuthURL` from `BackendState == "NeedsLogin"`, and opens the browser for standard SSO/Apple/Google sign-in.
  - Inbound raw TCP bridge on macOS host (`TailscaleService.startListener(port:)`): accepts incoming connections on the Tailnet and transparently proxies traffic to the local `RemoteServer` listener at `127.0.0.1:port`, preserving end-to-end TLS certificate fingerprint pinning, authentication, and HTTP/1.1 byte-range streaming.
  - **Background Helper Tailscale Node & Remote Wake-Up**:
    - Embedded `TailscaleKit` and `TailscaleService` into `Zude Helper` (`com.inovadev.zude.helper`), the background login item.
    - When `Zude.app` is closed, `Zude Helper` keeps the Mac's Tailscale node connected on the Tailnet and listens on the remote access port (32440).
    - When a remote device connects over Tailscale, `Zude Helper` accepts the connection, triggers `openZude()` to launch the main `Zude.app` in the background (hidden), and seamlessly bridges traffic to `127.0.0.1:32440` with retry polling while Zude boots.
    - Integrated `NSWorkspace` lifecycle listeners (`didLaunchApplicationNotification`, `didTerminateApplicationNotification`) to automatically relinquish the Tailscale listener to `Zude.app` when opened and re-arm it in `Zude Helper` when `Zude.app` terminates.
  - Cloud publishing in `RemoteDirectory` & `MacDirectory`: automatically includes `tailscaleAddress` in iCloud `RemoteServer` records, allowing paired mobile devices away from home to locate and dial the host over Tailscale.
  - SOCKS5 userspace proxy routing on iOS client (`applyProxy(to:)`): dynamically configures `URLSessionConfiguration` for `ZudeConnection` and `SongStreamer` to route through the local Tailscale loopback proxy when connecting to Tailscale CGNAT addresses (`100.64.0.0/10`), enabling full music and video streaming over cellular without router UPnP or IPv6.
  - **Movie & TV Show Remote Streaming over Tailscale with Range Seeking & Auto-Wake**:
    - Full remote video streaming pipeline for movies and TV shows indexed from local files and native Plex Media Server.
    - Video serving routes in `RemoteServer` support HTTP 206 Partial Content byte-range requests (`Accept-Ranges: bytes`) with pipelined 256KB chunk streaming for instantaneous seeking and scrubbing.
    - Integrated `SongStreamer.sessionProxyHook` with `TailscaleService.applyProxy(to:)`, routing `AVAssetResourceLoader` byte-range requests through the userspace SOCKS5 proxy whenever connecting to `100.x.y.z` Tailnet hosts.
    - Enhanced `PhoneVideoPlayer.start(_:at:)` in `VideoPlayer.swift` to automatically invoke `library.reachForPlaying()` to establish the remote link and wake the host Mac via `Zude Helper` before starting playback, eliminating premature "Connect to your Mac to watch this video" errors.
  - **Remote Song Metadata Updates, Song Downloads & Playable Game Library over Tailscale**:
    - **Song Metadata Sync (`PhoneEdits.swift`)**: Phone-side edits to song tags (titles, artists, albums, genres, years, lyrics, comments, and high-resolution cover photos), playlists (`PlaylistEdit`), artist photos, and suggestion marks automatically connect to and wake the Mac via `reachForPlaying()` before transmitting over `POST /v1/sync`, ensuring changes push immediately to the Mac's collection over Tailscale without waiting for periodic background sync intervals.
    - **Song Download Requests (`KeepOnPhone.swift`, `DiscoverDownloads.swift`, `ShazamScreen.swift`)**: When queuing songs or albums to download to the phone or requesting the Mac download music from Discover or Shazam, `KeepOnPhone` and `DiscoverDownloads` proactively trigger `reachForPlaying()`, establishing the proxied Tailscale connection to download audio files directly via `connection.download` (with increased 180s transfer timeout for lossless tracks).
    - **Playable Game Library Remote Browsing & Execution (`GamesScreen.swift`, `PhoneGamePlayer.swift`)**:
      - Mobile `PhoneGameShelf` seamlessly queries `GET /v1/games` and game covers over Tailscale, automatically invoking `reachForPlaying()` on view appear, pull-to-refresh (`pavoRefreshable`), and game launch so the Mac wakes and answers.
      - Increased `ZudeConnection.copyGame` transfer timeout to 300 seconds with unified request signing, ensuring large game ROMs (e.g. Nintendo DS games up to 512MB) download and unpack over cellular without timeouts.
      - Updated offline banners and error dialogs across the game player to support remote Tailscale connectivity instead of restricting to Wi-Fi.
  - Settings UI for Tailscale in both macOS `RemoteAccessSettings` ("Sign in with Tailscale", live connection status, "Sign Out") and iOS `SettingsScreen` ("TAILSCALE REMOTE ACCESS").
- **Device Pairing Card & PairedMac Tailscale Integration**:
  - Embedded the host Mac's Tailscale IP address into `RemotePairingCard.addresses` via `RemoteAccess.pairingCard(withCode:)`, providing the mobile client with the Tailscale direct address immediately upon scanning the QR code or discovering the Mac over Bluetooth.
  - Added `tailscaleAddress: String? = nil` to `PairedMac` in `ZudeConnection`, ensuring backward-compatible Codable persistence of the host's Tailscale IP on the device across app launches.
  - Updated `MacLibrary.pair(with:code:)` and `pair(with entry:)` to capture and store the host's Tailscale IP in `PairedMac`.
  - Enhanced `MacLibrary.findMac()` to proactively probe `paired.tailscaleAddress` alongside LAN and iCloud candidates when reconnecting away from home, ensuring instant cellular streaming without relying on peer-to-peer relays.
- **Lichii Support for Nintendo Switch 2**:
  - Registered Lichii as a first-class emulator core for Nintendo Switch 2 (`GameSystem.nintendoSwitch2`), allowing users to play Switch 2 titles with Lichii via the system settings and the game context "Play With" menu.
  - Added `EdenFolder.Build.lichii` supporting candidate bundle identifiers (`com.yuzu-emu.yuzu`, `me.zortos.lichii`, `io.github.zortos293.lichii`, `com.inovadev.zude.lichii`).
  - Automatically locates Lichii from `~/Applications/Lichii.app`, `/Applications/Lichii.app`, `~/Applications/Zude Lichii.app`, and `Reference Binaries/Gaming/lichii.app`.
  - Added dedicated build/install script `Vendor/Cores/Switch/Lichii/build-lichii.sh` to stage, strip quarantine, ad-hoc or Developer ID codesign, and register `Reference Binaries/Gaming/lichii.app` (or compile from `Reference Binaries/Gaming/Lichii-nx2` via CMake and Ninja).
  - Configured shared Switch 2 keys and firmware synchronization in `EdenFolder.prepare(bios:in:)`, mirroring `prod.keys` and NAND Contents to both `eden/` and `lichii/` directory roots.
  - Automatically writes `sdl2-config.ini` and `nx2_switches.txt` (`EDEN_NX2_SPLIT=2`, `EDEN_NX2_FENCE_BATCH=1`) for optimized Apple Silicon performance.
  - Added standalone emulator row in `GameCoresPage` and dynamic "Show in Finder" / "Update Core…" actions in `GameSystemsPage`.
  - Custom core importer (`CustomCoreManager`) detects Lichii bundles and automatically associates them with Nintendo Switch 2.
- **User-Updatable & Migratable Emulator Cores**:
  - In-app core importer (`CustomCoreManager`) supporting standalone `.app` bundles (such as `Zude Eden.app`, `Eden NX2.app`, and `Lichii.app`), Libretro `.dylib` cores, `.zip` archives, and backup core directories.
  - Automatic macOS security preparation: clears quarantine attributes (`xattr -cr`), applies ad-hoc codesigning (`codesign --force --deep --sign -`), and registers standalone applications with LaunchServices (`lsregister -f`).
  - Migration & Export: "Export Cores…" packages installed Libretro cores and standalone emulators alongside a portable `manifest.json` for easy transfer between Macs.
  - Cores Management UI (`GameCoresPage`): Added "Import Core…", "Export Cores…", and "Open Cores Folder" toolbar actions, plus a dedicated "Standalone Emulators" section for Switch (`Zude Eden`) and Switch 2 (`Zude Eden NX2`, `Lichii`) with "Show in Finder" and "Update Core…" buttons.
  - Per-Console Import (`GameSystemsPage`): Added "Import Core for <Console>…" directly on every system's settings panel.
  - Dynamic "Play With" Menu (`GamesView`): Game context menu now dynamically lists all available cores (both built-in and user-imported custom cores).
  - Persistence: Backwards-compatible `customCores: [GameSystem: [PlannedCore]]` in `GameLibraryFile`.
- **NX Native Compilation & Packaging Progress**:
  - Live compilation and packaging progress updates displayed directly in the bottom progress bar when compiling games with NX Native.
  - Added `--allow-other-metal` packaging flag support for NX Native games.
  - NX Native Switch 2 native runner integrated alongside Eden and Eden NX2.
- **Gameplay Now Playing Footer Peek**:
  - Hovering the mouse near the bottom of the screen (height expanded to 24 pt) while a game is actively running peeks the bottom Now Playing toolbar with glass/dark styling, matching the YouTube experience.
- **Collection & Discovery Enhancements**:
  - Added Discover search on mobile and Discover fallback in collection search.
  - Traced logo icon and console silhouette outline added for Nintendo Switch 2.
- **Nintendo Emulator Sleep & Turn-Off Signal**:
  - Registered system lifecycle observers for `NSWorkspace.willSleepNotification` and `NSApplication.willTerminateNotification` in `GamesStore` to signal active emulators (Eden, Eden NX2, Lichii) to power down and save state when the Mac goes to sleep or quits.
  - Linked `GamesStore.stopPlaying()` and `stopPlayingNow()` directly to `eden.quit()`, ensuring standalone and embedded emulators terminate immediately when gameplay ends.
  - Enhanced `EdenPlayer.quit()` termination wait with responsive polling (150ms intervals) before immediately delegating to `cores.endSwitch(pid)`.
  - Added power assertion activity management in `zude_view.cpp` using `NSProcessInfo` `beginActivity` and `endActivity`, releasing idle-sleep prevention when the emulator is paused or quit to eliminate battery drain while idle.
  - Updated SDL3 event loop in `yuzu.cpp` (`SDL_AppEvent`, `SDL_AppIterate`) to process `SDL_EVENT_QUIT` and `ZudeView::QuitRequested()`, returning `SDL_APP_SUCCESS` to shut down cleanly instead of ignoring quit events.

### Bugfixes
- **LibraryPanel Initializer Overloads & Binary Compatibility**:
  - Provided explicit backward-compatible initializer overloads for `LibraryPanel` in `MusicLibraryView.swift`, resolving missing synthesized default parameter linker errors across translation units when referencing `init(header:scrollToRow:indexTitles:rowHeight:perRow:accessory:rows:)`.
- **Album Action Buttons Circle Borders & Styling Consistency**:
  - Resolved missing circle borders on the Add to Playlist (`+`) and More options (`...`) buttons in `AlbumViewHeader`, `ArtistBanner`, and `MinimizedArtistHeader`.
  - Because macOS AppKit's `NSPopUpButton` / `SwiftUIPopupButton` ignores `.background` and `.overlay` modifiers on `Menu` when rendered inside an `NSHostingView`, refactored `Menu` to `.buttonStyle(.plain)` with the `Circle().strokeBorder(Color.white, lineWidth: 1.5)` border and hover fill placed directly inside the `label:` view hierarchy, achieving 100% visual styling consistency across all five action buttons (Play, Shuffle, +, Pin, and ...).
- **Artist List Alphabet Scroll Selector Collision**:
  - Increased trailing inset in `ArtistListRow` from `scrollerWidth + 32` to `scrollerWidth + 50` when `hasAlphabetIndex` is active.
  - Positioned the hover Smart DJ and Quickplay pin buttons further left to ensure they never overlap or collide with the alphabet index strip, even when letters scale up with hover magnification.
- **Tailscale Userspace Concurrency & Cross-Target Integration**:
  - Resolved Swift 6 actor isolation conflicts in `TailscaleService` by refactoring `TailscaleService` to `@Perceptible` with an explicit thread-safe lock (`NSLock`) guarding loopback proxy configuration, nonisolated synchronous helpers for `isTailscale(_:)` and `applyProxy(to:)`, and asynchronous dispatch to `MainActor` for UI-facing state changes (`state`, `authURL`, `tailscaleIP`).
  - Added backward-compatible fallback for URLSession proxy configuration (`connectionProxyDictionary` with `kCFStreamPropertySOCKSProxyHost`) for systems prior to macOS 14.0 / iOS 17.0 alongside `NWEndpoint` / `ProxyConfiguration`.
  - Added `RemoteAccess/TailscaleService.swift` to `Zude Mobile` synchronized build exceptions in `project.pbxproj` to ensure target compilation on iOS.
  - Linked `TailscaleKit` and added `ENABLE_INCOMING_NETWORK_CONNECTIONS` to `Zude Helper`, granting sandboxed socket listener permissions.
  - Resolved platform boundary issue for `stopListener()` across macOS and iOS targets.
  - Resolved cross-network cellular reachability for devices paired across different Apple IDs by persisting Tailscale addresses directly in `RemotePairingCard` and `PairedMac`, bypassing iCloud database isolation constraints.
  - Fixed CloudKit Production schema rejection (`The Zude container's schema may need deploying to Production` / `serverRejectedRequest`) by transmitting the Tailscale IP inside the existing `lanAddresses` list field rather than a dedicated undeployed field. Updated `RemoteDirectory` and `MacDirectory` to automatically detect Tailscale IPs within local addresses, completely eliminating the need for manual CloudKit schema migrations.
  - Made `TailscaleService.isTailscale(_:)` nonisolated static to prevent actor isolation warnings during synchronous URL session and endpoint proxy routing.
  - Fixed asynchronous `AVPlayer.seek(to:toleranceBefore:toleranceAfter:)` call in `PhoneVideoPlayer.start(_:at:)` under Swift 6 language mode.
  - Fixed `MusicLibraryView.threeColumns` layout to support optional `showsLast: Bool` parameter, dynamically expanding the album collection when no album is selected and restoring third-column tracks without compiler type-inference errors.
- **Nintendo Switch 2 (Eden NX2) Pushbuffer & MME Command Stream Desync**:
  - **Auto-Park Split Pushbuffer Methods (`dma_pusher.cpp`)**: Resolved pushbuffer command stream misalignment in `DmaPusher::Step` when games submit split method packets across non-contiguous entry boundaries. In Switch 2 Ampere rendering, when a method call payload was interrupted by an asynchronous call buffer or jump, DmaPusher previously treated the first word of the new buffer (a `CommandHeader` such as `0x3a400040`) as the remaining argument payload of pending method `0x47` (`load_mme.start_address_ptr`). This triggered `ProcessMacroBind out of bounds: ptr=0x3a400040 max=128` and shifted the entire pushbuffer stream by 1 word.
  - **Command Header Stream Shift & Unbound Subchannel Drops**: The 1-word shift caused parameter payloads to be decoded as invalid command headers (triggering `Dropping method 0x1a4d on unbound subchannel 6`) and subsequent command headers (`0x38400000`, `0x0e000001`) to be fed into Turing MME macro `0x1e7` as loop counters (`regs[2] = 0xa00f0e96` / 2.68 billion instead of 7), triggering fatal `Native MME failed: start=0x1e7, pc=0x1ef, consumed=6/6, error=instruction limit exceeded` and stalling rendering at `level 2 of 255` in 3D game sections (Crash Bandicoot). Implemented automatic split method parking (`park_split_methods`) in `DmaPusher` whenever `g_nx2_ampere` encounters a new entry starting with a valid command header, preserving exact command stream alignment.
  - **Render Target Format Sanitization (`fixed_pipeline_state.cpp`, `vk_pipeline_cache.cpp`)**: Fixed uninitialized render target format spam (`Unimplemented render target format 0x28, falling back to A8B8G8R8_UNORM`) by clamping `color_formats` copying to active render target count (`regs.rt_control.count`), explicitly zeroing unused target slots to `NONE` and skipping them during MoltenVK pipeline cache runtime info construction.
- **3D Shader Pipeline & Occlusion Rendering**:
  - **Occlusion Query Conditional Rendering (`maxwell_3d.cpp`)**: On Apple Silicon (MoltenVK) where `VK_EXT_conditional_rendering` is not accelerated, software query reads from asynchronous guest buffers frequently evaluated to false, skipping all 3D draw calls and producing black screens (level 20 of 255). Set `execute_on = true` when conditional rendering is unaccelerated, allowing Apple Silicon's hardware TBDR to handle hidden surface removal without dropping geometry.
  - **Pipeline Async Stalling (`vk_pipeline_cache.cpp`)**: Updated `BuiltPipeline` to return the pipeline rather than returning `nullptr` for depth-enabled (`zeta_enable`) draws during compilation, preventing 3D scenes from discarding draw calls while shaders compile.
  - **Persistent Disk Shader Cache (`EdenFolder.swift`)**: Enabled `use_disk_shader_cache=true` across release settings, persisting translated shaders to disk so 3D environments load shaders instantly without dropping initial frames.
- **3D Shader & Pipeline Crash Resolution (Crash Bandicoot & Bananza)**:
  - **Depth Format Fallback (`video_core/surface.cpp`)**: Replaced fatal `UNIMPLEMENTED_MSG` on depth format 28 (and other unmapped formats) in `PixelFormatFromDepthFormat` with warning logging and safe fallback to `PixelFormat::S8_UINT_D24_UNORM`, preventing assertion halts when games enter 3D environments.
  - **Resilient Vertex Formats (`video_core/renderer_vulkan/maxwell_to_vk.cpp`, `vk_pipeline_cache.cpp`)**: Replaced hard assert aborts on `UnusedEnumDoNotUseBecauseItWillGoAway` and unimplemented vertex formats (`type=0 and size=0`) with graceful `Shader::AttributeType::Disabled` casting and fallback to `VK_FORMAT_R32G32B32A32_SFLOAT`, eliminating fatal Metal pipeline validation crashes (`validateVertexDescriptor`) in MoltenVK.
  - **Pipeline Creation Guards (`vk_graphics_pipeline.cpp`, `vk_rasterizer.cpp`)**: Added vertex attribute format checks to substitute `VK_FORMAT_UNDEFINED` with `VK_FORMAT_R32G32B32A32_SFLOAT` before passing pipeline descriptors to Vulkan.
  - **Safe Format Queries (`video_core/vulkan_common/vulkan_device.cpp`)**: Guarded `IsFormatSupported` against `VK_FORMAT_UNDEFINED` and unmapped formats (returning `false` without crashing) and updated `GetSupportedFormat` to fallback safely to `VK_FORMAT_R32G32B32A32_SFLOAT`.
  - **Render Enable Condition Mode (`video_core/engines/maxwell_3d.cpp`)**: Replaced assertion abort on unimplemented condition modes with warning logging and execute pass-through (`execute_on = true`).
  - **Gameplay Debug Validation Toggle (`EdenFolder.swift`)**: Changed default renderer configuration from `debug=true` to `debug=false` in `settingsText` for release gameplay, preventing debug validation hooks and `brk #0` soft-assert breaks from halting execution.
  - **Lichii Migration Profile Bypass**: Automatically creates migration fresh flags (`.migration/fresh`) in both data root and home directory to prevent "Legacy emulator data or an unfinished import was found" runtime exceptions.
  - **Switch 1 Eden FFmpeg 63 Rebuild**: Recompiled and codesigned `~/Applications/Zude Eden.app` against updated Homebrew dynamic libraries (`libavcodec.63.dylib`), eliminating missing library crashes (`dyld[67927]: Library not loaded: .../libavcodec.62.dylib`) on launch.
- **Standalone Window Handshake & Activation**:
  - Streamlined window activation in `EdenPlayer` for standalone emulators (`Lichii`) to bring its window to the front without waiting for an embedded window handshake that only applies to Eden's in-window rendering.
  - Safe driver check in `EdenFolder.environment`: verifies `driver.json` exists before injecting `VK_DRIVER_FILES` to prevent MoltenVK crashes in bundles lacking a custom Vulkan ICD manifest.
  - Process cleanup: expanded `killAllEdenInstances()` and `endSwitch()` in `CoreInstallerHost` to scan and terminate lingering Lichii processes.
- **Main-Thread Unblocking (Cover Change & Settings)**:
  - Game cover changes (`chooseCover`) and emulator selection persistence now execute in background tasks, completely resolving UI freezes and beachball stalls when updating game metadata or switching between Eden and NX Native.
- **Development Mode Update Suppression**:
  - Suppressed automatic Sparkle update check loops, update alerts, and update popups when running development instances from Xcode, DerivedData, or under active debugging (`SoftwareUpdates.isDevelopment`).
- **Nintendo Switch 2 `.nup` Folder Scan**:
  - Restored `.nup` file extension to Nintendo Switch 2 supported extensions so folder searches and library scans detect `.nup` files.
- **Media Format Converter & Sandbox**:
  - Dynamic FFmpeg discovery: resolved symlinks and added runtime cache invalidation in `MediaFormatConverter`.
  - Granted sandbox exceptions to read and execute Homebrew/local helper tools (`ffmpeg`, `lame`).
  - Adjusted volume leveling curve to streaming standard (-14 LUFS) to prevent harsh clipping and distortion.
- **Eden Process Recovery**:
  - Fixed dead-process detection and native process cleanup via `libproc` in `EdenPlayer`.
  - Auto-kills orphaned or lingering Eden instances prior to launching games to prevent multi-instance launch errors.
  - Preserved `.cache` during `git clean` in `build-eden.sh`.
- **Display & State Tracking**:
  - Inhibited screensaver and automatic Now Playing screen takeover during active game sessions.
  - Fixed perceptible state tracking on `PlayerEngine.duration` and silenced perception warning spam.
  - Fixed `ZuneShell.location` perception tracking in binding getters.


## Now: version 1.1, committed and pushed, updates through Sparkle (asked 2026-11-08) — done; the feed's repository and the first release are yours

> "Now update the version to 1.1 and commit and push the repo, making sure that the repo is updateable through
> snowflake."

- Read as: version 1.1; the whole tree committed (in separate commits by topic) and pushed; and Zude able to update
  itself through Sparkle ("snowflake": nothing in the repo has that name; Zude updates through Sparkle).
- Found: the app had no Sparkle public key (`SPARKLE_PUBLIC_KEY` empty), so no build could install an update, and the
  feed's repository (github.com/Gold240sx/zude-updates, served at gold240sx.github.io/zude-updates) didn't exist.
- Done: MARKETING_VERSION 1.1 on every Apple target (Zude for Android stays 0.0.1); the public key from the login
  keychain's Sparkle key (`generate_keys -p`) in Zude/InjectDocumentTypes.sh — the built app has SUFeedURL and
  SUPublicEDKey. Tests: all 1,844 pass (8 stale ones brought up to date: Switch 2, the 3DS decrypter, Plex direct
  play, cloned game files).
- The feed's repository: made by the user (2026-11-08); cloned to build/updates with an empty appcast and Pages
  turned on (see below for what's left). Steps as they were:
  `gh repo create Gold240sx/zude-updates --public`, clone it to build/updates, add an empty appcast.xml and
  `.nojekyll`, push, and turn on GitHub Pages from main (`gh api -X POST repos/Gold240sx/zude-updates/pages
  -f 'source[branch]=main' -f 'source[path]=/'`). Then `Scripts/release.sh 1.1 --publish` (archives, notarizes,
  signs and publishes the update). Copies of Zude
  built before today have no key, so they can't take an update: install the first 1.1 by hand; from then on Zude
  updates itself. Keep a backup of the private key: `generate_keys -x <file>`.

