# Zude's PO Token Provider for yt-dlp.
#
# YouTube wants a proof-of-origin (PO) token with web clients' video and player requests; without one it answers
# 403, or with "Sign in to confirm you're not a bot". Zude makes them the way Downie does: with YouTube's own BotGuard
# running in a hidden web view (Zude/Downloader/YouTubeTokens.swift). This provider asks the Zude that started
# yt-dlp for one, for the content binding yt-dlp gives (a video id, the visitor data, or the account's data-sync id).
#
# Zude passes where to ask in ZUDE_POT_URL and a secret for this run in ZUDE_POT_SECRET. Without them (yt-dlp run
# by hand) the provider says it isn't available and yt-dlp carries on as it would have.
from __future__ import annotations

import json
import os

from yt_dlp.extractor.youtube.pot.provider import (
    PoTokenContext,
    PoTokenProvider,
    PoTokenProviderError,
    PoTokenProviderRejectedRequest,
    PoTokenRequest,
    PoTokenResponse,
    register_preference,
    register_provider,
)
from yt_dlp.extractor.youtube.pot.utils import WEBPO_CLIENTS, get_webpo_content_binding
from yt_dlp.networking.common import Request
from yt_dlp.networking.exceptions import RequestError


@register_provider
class ZudePTP(PoTokenProvider):
    PROVIDER_NAME = 'zude'
    PROVIDER_VERSION = '1.0.0'
    BUG_REPORT_LOCATION = 'https://github.com/Gold240sx/Zude/issues'
    _SUPPORTED_CLIENTS = WEBPO_CLIENTS
    _SUPPORTED_CONTEXTS = (PoTokenContext.GVS, PoTokenContext.PLAYER, PoTokenContext.SUBS)
    # The only request is to Zude on this Mac, through yt-dlp's own networking.
    _SUPPORTED_EXTERNAL_REQUEST_FEATURES = None

    def is_available(self) -> bool:
        return bool(os.environ.get('ZUDE_POT_URL') and os.environ.get('ZUDE_POT_SECRET'))

    def _real_request_pot(self, request: PoTokenRequest) -> PoTokenResponse:
        binding, _ = get_webpo_content_binding(request)
        if not binding:
            raise PoTokenProviderRejectedRequest('Nothing to bind a token to for this request')
        body = json.dumps({'binding': binding}).encode()
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + os.environ['ZUDE_POT_SECRET'],
        }
        try:
            response = self._request_webpage(
                Request(os.environ['ZUDE_POT_URL'], data=body, headers=headers, proxies={'all': None}),
                pot_request=request, note=False)
            answer = json.loads(response.read().decode())
        except RequestError as error:
            raise PoTokenProviderError(f'Zude could not make a token: {error}', expected=True) from error
        except ValueError as error:
            raise PoTokenProviderError(f'Zude sent back something unreadable: {error}', expected=True) from error
        token = answer.get('po_token')
        if not token:
            raise PoTokenProviderError(answer.get('error') or 'Zude made no token', expected=True)
        self.logger.trace(f'Token from Zude for {binding}')
        return PoTokenResponse(po_token=token, expires_at=answer.get('expires_at'))


@register_preference(ZudePTP)
def zude_preference(provider: PoTokenProvider, request: PoTokenRequest) -> int:
    return 100
